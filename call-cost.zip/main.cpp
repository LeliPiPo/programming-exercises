/*1. Write a program that computes the cost of a long-distance call. The cost of 
the call is determined according to the following rate schedule:
 a. Any call started between 8:00 am and 6:00 pm, Monday through Friday, 
is billed at a rate of $0.40 per minute.
 b. Any call starting before 8:00 am or after 6:00 pm, Monday through  
Friday, is charged at a rate of $0.25 per minute.
 c. Any call started on a Saturday or Sunday is charged at a rate of $0.15 
per minute.
 The input will consist of the day of the week, the time the call started, and 
the length of the call in minutes. The output will be the cost of the call. The 
time is to be input in 24-hour notation, so the time 1:30 pm is input as
 13:30
 The day of the week will be read as one of the following pairs of character 
values, which are stored in two variables of type char:
 Mo Tu We Th Fr Sa Su
 Be sure to allow the user to use either uppercase or lowercase letters or a 
combination of the two. The number of minutes will be input as a value 
of type int. (You can assume that the user rounds the input to a whole 
number of minutes.) Your program should include a loop that lets the 
user repeat this calculation until the user says she or he is done.*/
#include <iostream>
#include <string>
using namespace std;
int main()
{   
    const double BUSY_WEEK = 0.40; //COST PER minute
    const double SLOW_WEEK = 0.25; //COST PER minute
    const double WEEKEND = 0.15; //COST PER minute
    char choice;
    do{
    
    int day, hour, minute, duration;
    string callStart, minuteString, hourString, dayString;
    double cost(0), rate;
    cout << "to calculate the cost of call, please fill in the following fields: \n";
    cout << "number of the day in the week: ";
    cin >> day;
    cout << "\nHour when the call starts: ";
    cin >> hour;
    cout << "\nMinute when the call starts: ";
    cin >> minute;
    cout << "\nHow many minutes the call lasts: ";
    cin >> duration;
    
   hourString = to_string(hour);
   minuteString = to_string(minute);
    callStart = hourString + minuteString;
   // cout << callStart << endl;
    
    switch(day){
        case 1: dayString = "Monday";
                break;
        case 2: dayString = "Tuesday";
                break;
        case 3: dayString = "Wednesday";
                 break;
        case 4: dayString = "Thursday";
               break;
        case 5: dayString = "Friday";
               break;
        case 6: dayString = "Saturday";
               break;
        case 7: dayString = "Sunday";
                break;
    }
    
     if(dayString == "Sunday" ||  dayString == "Saturday"){
         rate = WEEKEND;
     }
     else{
         if(callStart >= "0800" && callStart <= "1800")
         rate = BUSY_WEEK;
         else rate = SLOW_WEEK;
     }
    
    cost = duration * rate;
    cout << "cost is " << cost;
    
    
    
    cout << "\nenter \"y\" if you wish to repeat this\n";
    cin >> choice;
    }while(choice == 'Y' || choice == 'y');
    
    cout << "\tEnd of program. Have a great day!";
    return 0;
}



/*#include <iostream>
#include <string>
#include <cctype> // For tolower
using namespace std;

int main() {
    const double BUSY_WEEK = 0.40;
    const double SLOW_WEEK = 0.25;
    const double WEEKEND = 0.15;

    char choice;

    do {
        char day1, day2;
        int hour, minute, duration;
        double rate, cost;

        cout << "To calculate the cost of the call, please fill in the following fields:\n";
        cout << "Enter the day of the week (e.g., Mo, Tu, We): ";
        cin >> day1 >> day2;

        // Convert to lowercase for case-insensitive comparison
        day1 = tolower(day1);
        day2 = tolower(day2);

        cout << "Enter the hour when the call starts (24-hour format): ";
        cin >> hour;

        cout << "Enter the minute when the call starts: ";
        cin >> minute;

        cout << "How many minutes the call lasts: ";
        cin >> duration;

        // Determine day
        string dayStr = string(1, day1) + string(1, day2);

        bool isWeekend = (dayStr == "sa" || dayStr == "su");

        if (isWeekend) {
            rate = WEEKEND;
        } else {
            int timeValue = hour * 100 + minute;
            if (timeValue >= 800 && timeValue <= 1800)
                rate = BUSY_WEEK;
            else
                rate = SLOW_WEEK;
        }

        cost = rate * duration;

        cout << "The cost of the call is: $" << cost << endl;

        cout << "Enter 'y' if you wish to repeat this: ";
        cin >> choice;

    } while (choice == 'y' || choice == 'Y');

    cout << "\nEnd of program. Have a great day!\n";
    return 0;
}
*/