/*37. Write a loop that will read in a list of even numbers (such as 2, 24, 8, 6) 
and compute the total of the numbers on the list. The list is ended with 
a sentinel value. Among other things, you must decide what would be a 
good sentinel value to use. */
#include <iostream>
using namespace std;
int main()
{  
   int number(0), sum(0);
   int even = number % 2;
   cout << "hiiii enter some numbers and -1 when finished\n";
   while(number != -1){
       
       cin >> number;
       int even = number % 2;
      if(even == 0)
      {sum += number;}
   }
    cout << sum;
    
    return 0;
}